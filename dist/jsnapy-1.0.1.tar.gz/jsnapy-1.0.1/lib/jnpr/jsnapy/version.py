#!/usr/bin/python

# Copyright (c) 1999-2016, Juniper Networks Inc.
#
# All rights reserved.
#

__version__ = "1.0.1"
DATE = "2016-Aug-26"
