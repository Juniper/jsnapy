# from __future__ import print_function
### performing function similar to --snapcheck option in command line ######
import sys
from StringIO import StringIO
old_stdout = sys.stdout
mystdout = StringIO()
sys.stdout = mystdout
sys.stderr = mystdout

from jnpr.jsnapy import SnapAdmin
from pprint import pprint
from jnpr.junos import Device

js = SnapAdmin()
config_file = "/Users/ishaank/Desktop/work-jsanpy/jsnapy/samples/config_check_no_test.yml"
snapvalue = js.snapcheck(config_file, "snap")
sys.stdout = old_stdout
print(mystdout.getvalue())

# for snapcheck in snapvalue:
#     print "\n -----------snapcheck----------"
#     print "Tested on", snapcheck.device
#     print "Final result: ", snapcheck.result
#     print "Total passed: ", snapcheck.no_passed
#     print "Total failed:", snapcheck.no_failed
#     pprint(dict(snapcheck.test_details))
